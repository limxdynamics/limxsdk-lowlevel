"""
@brief Touch-enabled dexterous hand command data classes.

Published on the "/brainco2/touch/hand/cmd" topic. Finger control follows DexHandCmd
exactly — same ``ctrl_mode`` values, same 6-finger padding. The extra ``tactile`` block
drives the touch sensors themselves and is independent of the finger motion mode.

``ctrl_mode`` selects which finger vectors are honoured per hand:

    0 = stop
    1 = position + time   (fill ``pos`` and ``time``)
    2 = position + speed  (fill ``pos`` and ``vel``)
    3 = current / force   (fill ``current``)

Tactile vectors are indexed by channel and passed through as given. Leaving one empty
means "do not touch that aspect on this hand", so sending finger motion without
reconfiguring the sensors is fine.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List

from .DexHandCmd import DexHandFingers


class TactileSwitches(object):
    """Per-hand tactile control block. Vectors are indexed by tactile channel."""

    __slots__ = ['channel_names', 'tactile_switch', 'channel_reset', 'calibration_trigger']
    channel_names: List[str]
    tactile_switch: List[int]
    channel_reset: List[int]
    calibration_trigger: List[int]

    def __init__(self):
        self.channel_names = []
        self.tactile_switch = []
        self.channel_reset = []
        self.calibration_trigger = []


class TactileHandCmd(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hands', 'tactile']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hands: List[DexHandFingers]
    tactile: List[TactileSwitches]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ''
        self.ctrl_mode = [0, 0]
        self.hands = [DexHandFingers(), DexHandFingers()]
        self.tactile = [TactileSwitches(), TactileSwitches()]
