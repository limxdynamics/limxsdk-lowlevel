"""
@brief Measured end-effector pose of both arms.

Fed from the "/arm/ee_pose_state" topic (geometry_msgs/PoseArray). The controller always
publishes exactly two poses: poses[0] is the left end effector, poses[1] the right one.

The fields below keep the historical layout of the retired "/arm_pose" flat array so
existing callers do not have to change:

    left_position / right_position   position (x, y, z)
    left_quat / right_quat           orientation, w-first (w, x, y, z)
    data                             the same values flattened to 14 floats,
                                     [left xyz + left wxyz, right xyz + right wxyz]

Notes:
  * The quaternion order in these fields is w-first, matching the manipulation
    controller's Cartesian servo protocol (xyz + qwxyz). PoseArray itself uses the
    named x/y/z/w fields, so the reordering happens inside the SDK.
  * PoseArray carries a header, so ``stamp`` is the publisher timestamp rather than
    the SDK receive time.
  * ``valid`` is False when a frame did not carry both poses; such frames are still
    delivered so a controller-side protocol change is visible instead of looking
    like "the arm stopped publishing".
  * The reference frame is declared on the wire via header.frame_id. Tron2 publishes
    base_Link; confirm the frame with the controller team before using the values
    for absolute positioning.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class ArmEePose(object):
    __slots__ = ['stamp', 'valid', 'left_position', 'left_quat',
                 'right_position', 'right_quat', 'data']
    stamp: int
    valid: bool
    left_position: List[float]
    left_quat: List[float]
    right_position: List[float]
    right_quat: List[float]
    data: List[float]

    def __init__(self):
        self.stamp = 0
        self.valid = False
        self.left_position = [0.0, 0.0, 0.0]
        self.left_quat = [0.0, 0.0, 0.0, 0.0]
        self.right_position = [0.0, 0.0, 0.0]
        self.right_quat = [0.0, 0.0, 0.0, 0.0]
        self.data = []
