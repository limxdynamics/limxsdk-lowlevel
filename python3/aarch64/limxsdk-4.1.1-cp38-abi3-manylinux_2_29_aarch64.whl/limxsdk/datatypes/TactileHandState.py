"""
@brief Touch-enabled dexterous hand feedback data class.

Fed from the "/brainco2/touch/hand/state" topic. This is DexHandState plus one
``TactileFingers`` per hand; ``ctrl_mode``, ``hands`` and ``tactile`` are all length 2,
indexed ``[left, right]``.

Tactile vectors are passed through as received — the channel count is decided by the
hand firmware (5 on the BrainCo2 touch hand), so they are not padded to a fixed size.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List

from .DexHandCmd import DexHandFingers


class TactileFingers(object):
    __slots__ = ['channel_names', 'normal_force', 'tangential_force',
                 'direction_angle', 'approximate_value', 'tactile_state']
    channel_names: List[str]
    normal_force: List[float]
    tangential_force: List[float]
    direction_angle: List[float]
    approximate_value: List[int]
    tactile_state: List[int]

    def __init__(self):
        self.channel_names = []
        self.normal_force = []
        self.tangential_force = []
        self.direction_angle = []
        self.approximate_value = []
        self.tactile_state = []


class TactileHandState(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hands', 'tactile']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hands: List[DexHandFingers]
    tactile: List[TactileFingers]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ''
        self.ctrl_mode = [0, 0]
        self.hands = [DexHandFingers(), DexHandFingers()]
        self.tactile = [TactileFingers(), TactileFingers()]
