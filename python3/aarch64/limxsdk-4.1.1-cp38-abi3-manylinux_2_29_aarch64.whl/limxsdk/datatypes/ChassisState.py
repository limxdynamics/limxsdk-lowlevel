"""
@brief Wheeled mobile base motion state data class.

Fed from the "/chassis/vel/state" topic (geometry_msgs/TwistStamped) at roughly 30 Hz:
``linear_velocity`` comes from ``twist.linear.x`` and ``angular_velocity`` from
``twist.angular.z``. ``data`` mirrors those two values so callers that used to read the
flat array of the retired "/chassis_state" keep working.

Notes:
  * ``steering_angle`` is always 0 — a Twist describes velocity only. The Ackermann
    steering angle is no longer broadcast; derive it from v and omega when needed.
  * TwistStamped carries a header, so ``stamp`` is the publisher timestamp rather than
    the SDK receive time.
  * The chassis node stops publishing while the chassis link is down, so a stale
    ``stamp`` means "no fresh chassis data", not "zero velocity".

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class ChassisState(object):
    __slots__ = ['stamp', 'linear_velocity', 'angular_velocity',
                 'steering_angle', 'data']
    stamp: int
    linear_velocity: float
    angular_velocity: float
    steering_angle: float
    data: List[float]

    def __init__(self):
        self.stamp = 0
        self.linear_velocity = 0.0
        self.angular_velocity = 0.0
        self.steering_angle = 0.0
        self.data = []
