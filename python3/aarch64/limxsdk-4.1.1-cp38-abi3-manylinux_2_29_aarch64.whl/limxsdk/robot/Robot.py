"""
@brief This file contains the declarations of classes related to the control of robots.

@file Robot.py

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

import sys
from typing import List
from typing import Callable, Any
import limxsdk.channel as channel
import limxsdk.datatypes as datatypes
import limxsdk.robot as robot

class Robot(object):
    """
    @class Robot
    @brief Represents a robot with various functionalities.

    This class provides an interface to interact with different types of robots.
    """

    def __init__(self, robot_type: robot.RobotType, is_sim: bool = False):
        """
        @brief Initializes a Robot object with a specified type and simulation mode.

        This constructor initializes a robot instance based on the provided robot type and 
        whether it's for simulation or real-world operation. It sets up the necessary components
        for the robot's operation, such as the robot's IP address and its native instance.

        @param robot_type: Specifies the type of the robot. Possible values are:
                          - robot.RobotType.PointFoot: Represents a PointFoot robot.
                          - robot.RobotType.Wheellegged: Represents a Wheellegged robot.
                          
        @param is_sim: Boolean flag indicating whether the robot is running in simulation mode (True)
                      or real-world mode (False). The default value is False (real-world mode).

        The following attributes are initialized:
        @attribute robot_ip: Default IP address for the robot, set to '127.0.0.1'.
        @attribute robot: A native instance of the robot, either a PointFoot or Wheellegged type,
                          based on the provided `robot_type` argument.

        @return None
        """

        __slots__ = ['robot', 'robot_ip']

        # Default robot IP address
        self.robot_ip = '127.0.0.1'

        # Create a native robot instance based on the specified type
        if robot_type == robot.RobotType.PointFoot:
            self.robot = robot.RobotNative("PointFoot", is_sim)
        elif robot_type == robot.RobotType.Wheellegged:
            self.robot = robot.RobotNative("Wheellegged", is_sim)
        elif robot_type == robot.RobotType.Humanoid:
            self.robot = robot.RobotNative("Humanoid", is_sim)
        elif robot_type == robot.RobotType.Tron2:
            self.robot = robot.RobotNative("Tron2", is_sim)
        elif robot_type == robot.RobotType.Centaur:
            self.robot = robot.RobotNative("Centaur", is_sim)

    def init(self, robot_ip: str = "127.0.0.1"):
        """
        @brief Initializes the robot with a specified IP address.

        @param robot_ip: IP address of the robot.
        @return: True if initialization is successful, False otherwise.
        """
        self.robot_ip = robot_ip
        return self.robot.init(self.robot_ip)

    def getMotorNumber(self):
        """
        @brief Gets the number of motors of the robot.

        @return: Number of motors.
        """
        return self.robot.getMotorNumber()
  
    def getMotorNames(self) -> List[str]:
        """
        @brief Gets the list of motor names of the robot.

        @return: A list of strings representing the names of each motor.
        """
        return self.robot.getMotorNames()

    def subscribeImuData(self, callback: Callable[[datatypes.ImuData], Any]):
        """
        @brief Subscribes to receive updates on the robot's imu.

        @param callback: Callable[[datatypes.ImuData], Any]: 
                  Callback function to handle imu updates.
        @return: Subscription status.
        """
        return self.robot.subscribeImuData(callback)

    def subscribeRobotState(self, callback: Callable[[datatypes.RobotState], Any]):
        """
        @brief Subscribes to receive updates on the robot's state.

        @param callback: Callable[[datatypes.RobotState], Any]: 
                  Callback function to handle robot state updates.
        @return: Subscription status.
        """
        return self.robot.subscribeRobotState(callback)

    def subscribeRobotCmd(self, callback: Callable[[datatypes.RobotCmd], Any]):
        """
        @brief Subscribes to receive robot command; used for collecting/analyzing RobotCmd data during physical robot operation

        @param callback: Callable[[datatypes.RobotCmd], Any]: 
                      Callback function to handle robot command updates.
        @return: Subscription status.
        """
        return self.robot.subscribeRobotCmd(callback)

    def publishRobotCmd(self, cmd: datatypes.RobotCmd):
        """
        @brief Publishes a robot command.

        @param cmd: Robot command to be published.
        @return: Status of the command publication.
        """
        return self.robot.publishRobotCmd(cmd)

    # For Centaur, the existing unqualified motor/IMU APIs address the lower
    # body. These explicit aliases make multi-body call sites self-documenting.
    def getLowerBodyMotorNumber(self):
        return self.robot.getLowerBodyMotorNumber()

    def getLowerBodyMotorNames(self) -> List[str]:
        return self.robot.getLowerBodyMotorNames()

    def subscribeLowerBodyImuData(self, callback: Callable[[datatypes.ImuData], Any]):
        return self.robot.subscribeLowerBodyImuData(callback)

    def subscribeLowerBodyRobotState(self, callback: Callable[[datatypes.RobotState], Any]):
        return self.robot.subscribeLowerBodyRobotState(callback)

    def subscribeLowerBodyRobotCmd(self, callback: Callable[[datatypes.RobotCmd], Any]):
        return self.robot.subscribeLowerBodyRobotCmd(callback)

    def publishLowerBodyRobotCmd(self, cmd: datatypes.RobotCmd):
        return self.robot.publishLowerBodyRobotCmd(cmd)

    def getUpperBodyMotorNumber(self):
        return self.robot.getUpperBodyMotorNumber()

    def getUpperBodyMotorNames(self) -> List[str]:
        return self.robot.getUpperBodyMotorNames()

    def subscribeUpperBodyImuData(self, callback: Callable[[datatypes.ImuData], Any]):
        return self.robot.subscribeUpperBodyImuData(callback)

    def subscribeUpperBodyRobotState(self, callback: Callable[[datatypes.RobotState], Any]):
        return self.robot.subscribeUpperBodyRobotState(callback)

    def subscribeUpperBodyRobotCmd(self, callback: Callable[[datatypes.RobotCmd], Any]):
        return self.robot.subscribeUpperBodyRobotCmd(callback)

    def publishUpperBodyRobotCmd(self, cmd: datatypes.RobotCmd):
        return self.robot.publishUpperBodyRobotCmd(cmd)

    def subscribeSensorJoy(self, callback: Callable[[datatypes.SensorJoy], Any]):
        """
        @brief Subscribes to receive sensor joy updates.

        @param callback: Callable[[datatypes.SensorJoy], Any]: 
                  Callback function to handle sensor joy updates.
        @return: Subscription status.
        """
        return self.robot.subscribeSensorJoy(callback)

    def subscribeDiagnosticValue(self, callback: Callable[[datatypes.DiagnosticValue], Any]):
        """
        @brief Subscribes to receive diagnostic value updates.

        @param callback (Callable[[datatypes.DiagnosticValue], Any]): 
                  Callback function to handle diagnostic value updates.
        @return: Subscription status.
        """
        return self.robot.subscribeDiagnosticValue(callback)

    def setRobotLightEffect(self, effect: datatypes.LightEffect):
        """
        @brief Sets the robot's light effect.

        This method configures the robot's light effect based on the provided effect parameter.
        The `effect` parameter should be an instance of the `LightEffect` enum, which provides 
        predefined values for different light effects. The enum value is converted to its integer 
        representation before being sent to the robot's API.

        @param effect: An instance of the `LightEffect` enum representing the desired robot light effect. 
                      The method converts this enum value to an integer to be compatible with the underlying 
                      robot API. Refer to the `LightEffect` enum for valid values. For example:
                      - `datatypes.LightEffect.STATIC_RED` corresponds to a static red light.
                      - `datatypes.LightEffect.FAST_FLASH_BLUE` corresponds to a fast-flashing blue light.

        @return: `True` if the light effect was successfully set, `False` otherwise. The return value indicates
                whether the operation was successful.
        """
        # Convert the enum to its integer value and call the robot's method
        return self.robot.setRobotLightEffect(effect.value)

    def subscribeRobotCmdForSim(self, callback: Callable[[datatypes.RobotCmd], Any]):
        """
        @brief Subscribes to receive robot command updates for simulation.

        @param callback: Callable[[datatypes.RobotCmd], Any]: 
                      Callback function to handle robot command updates.
        @return: Subscription status.
        """
        return self.robot.subscribeRobotCmdForSim(callback)
    
    def publishRobotStateForSim(self, state: datatypes.RobotState):
        """
        @brief Publishes the robot's state for simulation.

        @param state: Robot state to be published.
        @return: Status of the state publication.
        """
        return self.robot.publishRobotStateForSim(state)

    def publishImuDataForSim(self, imudata: datatypes.ImuData):
        """
        @brief Publishes IMU data for simulation.

        @param imudata: IMU data to be published.
        @return: Status of the IMU data publication.
        """
        return self.robot.publishImuDataForSim(imudata)

    def subscribeLowerBodyRobotCmdForSim(self, callback: Callable[[datatypes.RobotCmd], Any]):
        return self.robot.subscribeLowerBodyRobotCmdForSim(callback)

    def publishLowerBodyRobotStateForSim(self, state: datatypes.RobotState):
        return self.robot.publishLowerBodyRobotStateForSim(state)

    def publishLowerBodyImuDataForSim(self, imudata: datatypes.ImuData):
        return self.robot.publishLowerBodyImuDataForSim(imudata)

    def subscribeUpperBodyRobotCmdForSim(self, callback: Callable[[datatypes.RobotCmd], Any]):
        return self.robot.subscribeUpperBodyRobotCmdForSim(callback)

    def publishUpperBodyRobotStateForSim(self, state: datatypes.RobotState):
        return self.robot.publishUpperBodyRobotStateForSim(state)

    def publishUpperBodyImuDataForSim(self, imudata: datatypes.ImuData):
        """
        @brief Publishes Centaur upper-body IMU data for simulation.

        @param imudata: IMU data published on "/did_upbody/ImuData".
        @return: True when the native publisher accepts the message.
        """
        return self.robot.publishUpperBodyImuDataForSim(imudata)
    
    def publishDiagnostic(self, name: str, part: str, code: int, level: int = 0, message: str = ""):
        """
        Publish a diagnostic message about the robot's status.
        
        This method sends a diagnostic message to the system, providing information
        about the robot's status. Diagnostic messages are used to report issues,
        warnings, or normal operation of various components.
        
        Args:
            name: The name of the diagnostic message or the reporting component.
            part: The specific part or subsystem of the robot that the message relates to.
            code: A numeric code identifying the specific diagnostic condition.
            level: The severity level of the diagnostic message:
                   - 0: OK (normal operation, no issues)
                   - 1: Warning (a non-critical issue that should be noted)
                   - 2: Error (a critical issue that requires attention)
            message: A human-readable string providing additional details about the condition.
        """
        return self.robot.publishDiagnostic(name, part, code, level, message)
    
    def publishJsonMessage(self, json_payload: str):
      """
      @brief Sends a JSON-formatted message to the robot's high-level API.
        
      Used for custom commands or interactions not covered by the standard API.
        
      @param json_payload JSON string adhering to the robot's API protocol.
                    Example: {"accid": "xxx", "title": "request_xxx", "timestamp": xxx, "guid": "xxx", "data": {}}
      """
      return self.robot.publishJsonMessage(json_payload)

    def subscribeJsonMessage(self, callback: Callable[[str], Any]):
      """
      @brief Registers a callback to handle JSON-formatted responses and notifications from the robot.

      The callback will be invoked in two scenarios:
      1. When the robot sends a response to a previously sent JSON command (publishJsonMessage)
      2. When the robot initiates a notification (unsolicited message)
      
      @param cb Callback function with signature:
                void(const std::string &json_payload)
                where json_payload contains:
                - Response to a command: {"accid": "xxx", "title": "response_xxx", "timestamp": xxx, "guid": "xxx", "data": {}}
                - Notification: {"accid": "xxx", "title": "notify_xxx", "timestamp": xxx, "guid": "xxx", "data": {}}
      """
      return self.robot.subscribeJsonMessage(callback)

    def subscribeTerrainData(self, callback: Callable[[datatypes.TerrainData], Any]):
      """
      @brief Subscribes to receive terrain data updates from the robot.

      @param callback (Callable[[datatypes.TerrainData], Any]): 
                Callback function to handle terrain data updates, with a single argument of TerrainData type and no fixed return value.
      @return: Subscription status (success/failure flag or subscription handle).
      """
      return self.robot.subscribeTerrainData(callback)
    
    def publishTerrainDataForSim(self, data: datatypes.TerrainData):
      """
      @brief Publishes terrain data for robot simulation.

      @param data (datatypes.TerrainData): 
                Terrain data object (containing timestamp and serialized terrain metrics like elevation/slope) 
                to be published in the simulation environment.
      @return: Status of the terrain data publication (True for success, False for failure).
      """
      return self.robot.publishTerrainDataForSim(data)

    def publishGripperCmd(self, cmd: datatypes.GripperCmd):
        """
        @brief Publishes a command to drive the Tron2 2F-gripper.

        Tron2 only. The command is published on the dedicated topic
        "/limx/2F-gripper/cmd" (na=2, [left, right]). Each entry is a
        percentage in [0, 100]:
          - cmd.opening[0/1] : commanded opening (0=closed, 100=open)
          - cmd.speed[0/1]   : commanded motion speed
          - cmd.force[0/1]   : commanded grasping force

        The SDK internally clamps to [0, 100] and forces the right-finger
        opening upper bound to 95 to match the signaling-layer behavior.

        @param cmd: datatypes.GripperCmd with size-2 opening/speed/force lists.
        @return: True on success, False otherwise.
        """
        return self.robot.publishGripperCmd(cmd)

    def subscribeGripperState(self, callback: Callable[[datatypes.GripperState], Any]):
        """
        @brief Subscribes to Tron2 2F-gripper state feedback.

        @param callback: Callable[[datatypes.GripperState], Any]:
                Callback invoked from a dedicated dispatch thread when a new
                state on "/limx/2F-gripper/state" is received.
        @return: Subscription status.
        """
        return self.robot.subscribeGripperState(callback)

    def subscribeGripperCmdForSim(self, callback: Callable[[datatypes.GripperCmd], Any]):
        """
        @brief Simulator-side: subscribe to 2F-gripper commands from the controller.

        The command is published by the controller on "/limx/2F-gripper/cmd"; the
        simulator uses this callback to drive its (simulated) gripper.

        @param callback: Callable[[datatypes.GripperCmd], Any]:
                Callback invoked with each incoming GripperCmd (opening/speed/force).
        @return: Subscription status.
        """
        return self.robot.subscribeGripperCmdForSim(callback)

    def publishGripperStateForSim(self, state: datatypes.GripperState):
        """
        @brief Simulator-side: publish 2F-gripper state feedback ("/limx/2F-gripper/state").

        @param state: datatypes.GripperState with q/v/vd/tau lists (per finger).
        @return: True if publishing is successful.
        """
        return self.robot.publishGripperStateForSim(state)

    # ------------------------------------------------------------------
    # Machine data channels (Tron2 only)
    #
    # These channels each allow a single callback per process: registering a
    # second callback for the same channel replaces the first one.
    #
    # Unlike the older channels, the object handed to the callback is freshly
    # built for every frame, so it stays valid after the callback returns and can
    # be queued or stored without copy.deepcopy().
    #
    # The callback runs on the receive thread of its topic, so a slow callback
    # delays that topic (and only that topic). Do not block in it.
    # ------------------------------------------------------------------

    def subscribeGripperCmd(self, callback: Callable[[datatypes.GripperCmd], Any]):
        """
        @brief Subscribes to the commands being sent to the Tron2 2F-gripper.

        Read-back channel for "/limx/2F-gripper/cmd": it reports what is being
        commanded, including commands issued by other nodes, without taking control.

        @param callback: Callable[[datatypes.GripperCmd], Any]:
                Callback invoked with each observed GripperCmd (opening/speed/force).
        @return: Subscription status.
        """
        return self.robot.subscribeGripperCmd(callback)

    def subscribeLifterState(self, callback: Callable[[datatypes.LifterState], Any]):
        """
        @brief Subscribes to lifting column ("lifter") feedback ("/lifter/state").

        Only the mobile dual-arm configuration has a lifter; on other
        configurations the callback is never invoked.

        The reported values are raw controller-side quantities, not millimetres.

        @param callback: Callable[[datatypes.LifterState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeLifterState(callback)

    def subscribeLifterStatus(self, callback: Callable[[datatypes.LifterStatus], Any]):
        """
        @brief Subscribes to lifting column status in millimetres ("/lifter/status", ~20 Hz).

        This is the channel to use alongside publishLifterVel() / publishLifterPos():
        its position and velocity are already in the same millimetre units as those
        commands, and its flags are the only way to see that a command was rejected
        (uncalibrated, no feedback yet) or altered (speed fallback, target clamped).

        Unlike subscribeLifterState(), frames arrive whenever the chassis node is up,
        including before any lifter command has been sent.

        @param callback: Callable[[datatypes.LifterStatus], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeLifterStatus(callback)

    def subscribeChassisState(self, callback: Callable[[datatypes.ChassisState], Any]):
        """
        @brief Subscribes to wheeled-base motion feedback ("/chassis/vel/state", ~30 Hz).

        Provides linear velocity, angular velocity and steering angle. The chassis
        node stops publishing while the chassis link is down, so a stale stamp means
        "no fresh data", not "zero velocity".

        @param callback: Callable[[datatypes.ChassisState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeChassisState(callback)

    def subscribeArmEePose(self, callback: Callable[[datatypes.ArmEePose], Any]):
        """
        @brief Subscribes to the measured end-effector pose of both arms ("/arm/ee_pose_state").

        Each arm reports position (x, y, z) and a w-first quaternion (w, x, y, z).
        The reference frame is defined by the manipulation controller and is not
        declared on the wire.

        @param callback: Callable[[datatypes.ArmEePose], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeArmEePose(callback)

    def subscribeDexHandState(self, callback: Callable[[datatypes.DexHandState], Any]):
        """
        @brief Subscribes to dexterous-hand feedback ("/brainco2/hand/state").

        @param callback: Callable[[datatypes.DexHandState], Any]:
                Callback receiving ctrl_mode and per-hand finger feedback,
                indexed [left, right].
        @return: Subscription status.
        """
        return self.robot.subscribeDexHandState(callback)

    def publishDexHandCmd(self, cmd: datatypes.DexHandCmd):
        """
        @brief Publishes a command to the dexterous hand pair ("/brainco2/hand/cmd").

        cmd.ctrl_mode and cmd.hands must both have length 2, ordered [left, right].
        Per hand, the control mode selects which finger vectors are honoured:
          1 = position + time  -> hands[i].pos, hands[i].time
          2 = position + speed -> hands[i].pos, hands[i].vel
          3 = current          -> hands[i].current
        Mode 0 stops that hand.

        Finger vectors are zero-padded / truncated to the hand's finger count (6).

        @param cmd: datatypes.DexHandCmd
        @return: True on success, False otherwise.
        """
        return self.robot.publishDexHandCmd(cmd)

    def subscribeWujiHandState(self, callback: Callable[[datatypes.DexHandState], Any]):
        """
        @brief Subscribes to Wuji dexterous-hand feedback ("/wuji/hand/state").

        Same message type, DTO and [left, right] slot convention as the BrainCo2 pair;
        only the topic differs, so a robot fitted with Wuji hands uses this call
        instead of subscribeDexHandState().

        @param callback: Callable[[datatypes.DexHandState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeWujiHandState(callback)

    def publishWujiHandCmd(self, cmd: datatypes.DexHandCmd):
        """
        @brief Publishes a command to the Wuji dexterous hand pair ("/wuji/hand/cmd").

        Payload rules are identical to publishDexHandCmd(). Set cmd.hand_type to
        "wuji/hand" so downstream consumers can tell the vendor apart.

        @param cmd: datatypes.DexHandCmd
        @return: True on success, False otherwise.
        """
        return self.robot.publishWujiHandCmd(cmd)

    def subscribeTactileHandState(self, callback: Callable[[datatypes.TactileHandState], Any]):
        """
        @brief Subscribes to touch-enabled dexterous-hand feedback
               ("/brainco2/touch/hand/state").

        Reports everything subscribeDexHandState() does plus one TactileFingers per
        hand (normal / tangential force, direction, proximity, per-channel status).
        A robot fitted with touch hands uses this call instead of
        subscribeDexHandState() — the two feed different topics and only one is live.

        @param callback: Callable[[datatypes.TactileHandState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeTactileHandState(callback)

    def publishTactileHandCmd(self, cmd: datatypes.TactileHandCmd):
        """
        @brief Publishes a command to the touch-enabled dexterous hand pair
               ("/brainco2/touch/hand/cmd").

        Finger control follows publishDexHandCmd() exactly. The extra cmd.tactile block
        drives the sensors themselves (enable / reset / calibrate); leaving one of its
        vectors empty leaves that aspect untouched, so moving fingers without
        reconfiguring the sensors is fine.

        @param cmd: datatypes.TactileHandCmd
        @return: True on success, False otherwise.
        """
        return self.robot.publishTactileHandCmd(cmd)

    def subscribeVrState(self, callback: Callable[[datatypes.VrState], Any]):
        """
        @brief Subscribes to VR head-set / hand-controller state ("/vr_cmd").

        Read-only observation channel: it reports what the physical VR device is
        publishing. Poses are row-major 4x4 transforms (16 floats each).

        @param callback: Callable[[datatypes.VrState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeVrState(callback)

    def subscribeTeleopState(self, callback: Callable[[datatypes.TeleopState], Any]):
        """
        @brief Subscribes to tele-operation status.

        Decoded from the "TeleOperation" entry of "/diagnostics_value". See
        datatypes.TeleopState for the value convention; in particular the
        take-over flag is edge published, so ``takeover_known`` is False until
        the first take-over frame arrives.

        @param callback: Callable[[datatypes.TeleopState], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeTeleopState(callback)

    def subscribeDiagnosticByName(self, name: str,
                                  callback: Callable[[datatypes.DiagnosticEntry], Any]):
        """
        @brief Subscribes to one named entry of the robot diagnostic stream.

        Filters "/diagnostics_value" by ``name`` and delivers every matching
        frame as-is, including ``frame_id``. This is the general-purpose escape
        hatch for the diagnostics that have no dedicated accessor; run
        ``mrostopic echo /diagnostics_value`` on the robot to discover names.

        Unlike subscribeDiagnosticValue(), frames are neither coalesced per name
        nor delayed at start-up, and ``frame_id`` is preserved. Calling this
        again with the same name replaces that name's callback.

        @param name: Exact diagnostic name to match, e.g. "TeleOperation".
        @param callback: Callable[[datatypes.DiagnosticEntry], Any]
        @return: Subscription status.
        """
        return self.robot.subscribeDiagnosticByName(name, callback)

    def publishChassisTwist(self, linear_x: float, angular_z: float,
                            linear_y: float = 0.0):
        """
        @brief Drives the wheeled mobile base ("/sdk_cmd_vel").

        STREAMING interface, not a one-shot command: the base stops if no frame
        arrives for 300 ms, so keep publishing at about 10 Hz while motion should
        continue and send a zero frame to stop.

        Arguments are NORMALISED to [-1, 1], not physical units; the base applies
        its own velocity scaling. Values outside the range are clamped.

        The base reserves the Twist field ``linear.z`` for lifting-column jog and
        skips base motion on any frame where it is non-zero. This method always
        sends ``linear.z = 0``, so base motion is never suppressed; use
        publishLifterVel() / publishLifterPos() for the column, which run on
        separate topics and therefore work while the base is moving.

        @param linear_x: Forward / backward, normalised [-1, 1].
        @param angular_z: Steering, normalised [-1, 1].
        @param linear_y: Lateral; accepted but currently ignored by the Ackermann base.
        @return: True if the command was published.
        """
        return self.robot.publishChassisTwist(linear_x, angular_z, linear_y)

    def publishLifterVel(self, vel_mm_s: float):
        """
        @brief Drives the lifting column by velocity ("/sdk_lifter_vel").

        STREAMING interface: publish at about 10 Hz while motion should continue.
        If frames stop for more than 300 ms the column latches its measured
        position and holds.

        ``vel_mm_s == 0`` means "stop now": the column latches its measured
        position and releases the streaming control slot. That stop frame is
        accepted even without position feedback.

        Base behaviour to be aware of: a speed magnitude outside the configured
        limit falls back to the default speed rather than being clamped to the
        limit; travel limits are enforced by the base; and frames are dropped
        outright while the column is uncalibrated or "/lifter/state" feedback is
        missing, so nothing ever moves blind.

        Do not publish to "/lifter/cmd": that is the chassis node's own output to
        the controller, and writing it fights the node.

        @param vel_mm_s: Velocity in mm/s; positive raises, negative lowers, 0 stops.
        @return: True if the command was published.
        """
        return self.robot.publishLifterVel(vel_mm_s)

    def publishLifterPos(self, pos_mm: float, vel_limit_mm_s: float = 0.0):
        """
        @brief Drives the lifting column to a height ("/lifter/pos/cmd").

        STREAMING interface with the same 300 ms watchdog as publishLifterVel().
        Keep publishing while the move should continue; the target may be changed
        on any frame. On arrival the column holds rather than ending the task.

        There is no "0 = stop" convention here, because 0 mm is the valid lowest
        position. To stop, send one publishLifterVel(0) frame or simply stop
        publishing and let the watchdog latch.

        Targets outside the column's travel are clamped by the base. The same
        uncalibrated / no-feedback drop rules as publishLifterVel() apply.

        @param pos_mm: Target height in mm, 0 = lowest position.
        @param vel_limit_mm_s: Speed limit in mm/s; absolute value is used. Pass 0
                               to let the base apply its configured default speed.
        @return: True if the command was published.
        """
        return self.robot.publishLifterPos(pos_mm, vel_limit_mm_s)

    def subscribe(self, message_class, topic: str, callback: Callable[[Any], Any]):
        """
        @brief Subscribes to any mros topic through a generated message mirror.

        The subscribeXxx() methods above each expose one hand-written DTO. This
        one instead takes a generated class from limxsdk.msg (produced by
        tools/limxsdk-gen) and delivers the message exactly as declared on the
        wire, so a topic can be consumed without adding a new SDK entry point
        and without rebuilding the native extension:

            from limxsdk.msg import JointState
            sub = robot.subscribe(JointState, "/motor/state", on_frame)

        It lives on Robot rather than in a module-level function because a
        subscription needs the mros node that Robot.init() brings up; a free
        function would have to reach for a hidden global to find it.

        mros matches a subscription on type + md5, and a mismatch produces a
        subscription that simply never fires, so a silent topic means either
        nothing publishes it or the publisher's schema is not this one.

        The callback runs on the receive thread of its topic, so a slow callback
        delays that topic (and only that topic). Do not block in it. The object
        it receives is freshly built per frame and never mutated afterwards, so
        it can be queued or read from another thread without copy.deepcopy().

        @param message_class: a class from limxsdk.msg, e.g. msg.JointState.
        @param topic: topic name, e.g. "/motor/state".
        @param callback: Callable[[message_class], Any].
        @return: a channel.Subscription. Dropping it unsubscribes, so keep a
                 reference; it also exposes frames / decode_errors / close().
        """
        return channel.Subscription(self.robot, message_class, topic, callback)

    def publish(self, message_class, topic: str):
        """
        @brief Advertises any mros topic through a generated message mirror.

        The publishXxx() methods above each send one hand-written DTO. This one
        instead takes a generated class from limxsdk.msg and returns a publisher
        handle; calling handle.publish(msg) encodes the object in Python and
        ships the bytes, so a topic can be written without adding a new SDK
        entry point and without rebuilding the native extension:

            from limxsdk.msg import JointCmd
            pub = robot.publish(JointCmd, "/motor/cmd")
            pub.publish(JointCmd())

        It lives on Robot rather than in a module-level function because a
        publisher needs the mros node that Robot.init() brings up.

        Named publish (not advertise) to stay symmetric with Robot.subscribe().
        The returned handle is what you hold: dropping it unadvertises.

        @param message_class: a class from limxsdk.msg, e.g. msg.JointCmd.
        @param topic: topic name, e.g. "/motor/cmd".
        @return: a channel.Publisher. Dropping it unadvertises, so keep a
                 reference; it also exposes frames / close() / publish(msg).
        """
        return channel.Publisher(self.robot, message_class, topic)

    @staticmethod
    def _topic_info_dicts(rows):
        """Turn native (name, type, md5, definition) tuples into list[dict]."""
        return [{"name": row[0], "type": row[1], "md5": row[2], "definition": row[3]}
                for row in rows]

    def get_topics(self, duration: int = 3):
        """
        @brief Topics visible in this mros domain (any live publisher or subscriber).

        Requires a successful init() first: discovery talks to the mros node
        that init() brings up. Blocks up to @p duration seconds waiting for
        peers; 3 s is the mros default and is an upper bound, not a typical wait.

        Each item is a dict with keys name / type / md5 / definition. definition
        is frequently the empty string — live discovery often does not fill it
        in. Matching never uses it. Lazy channels that have not been opened yet
        do not appear.

        When MROS_DOMAIN_ID is a non-MAC token, mros prefixes names with
        ``/did_<id>/``.

        Do not call native getTopics() from user code; this wrapper is the
        public face, the same way subscribe() wraps openSub().

        @param duration: Discovery wait in seconds.
        @return: list[dict].
        """
        return self._topic_info_dicts(self.robot.getTopics(duration))

    def get_published_topics(self, duration: int = 3):
        """
        @brief Topics that currently have a publisher in this mros domain.

        Domain-wide (that is how mros reports it), not "this process only".
        Same init requirement, duration behaviour, and return shape as
        get_topics().
        """
        return self._topic_info_dicts(self.robot.getPublishedTopics(duration))

    def get_subscribed_topics(self, duration: int = 3):
        """
        @brief Topics that currently have a subscriber in this mros domain.

        Domain-wide (that is how mros reports it), not "this process only".
        Same init requirement, duration behaviour, and return shape as
        get_topics().
        """
        return self._topic_info_dicts(self.robot.getSubscribedTopics(duration))

    def query_topic_support(self, duration: int = 3):
        """
        @brief Live topic list crossed with the generated TYPE+MD5 registry.

        For each visible topic:

          * mirrored: the SDK ships a generated class for this type
          * md5_match: that class's MD5 equals the peer's

        A type the SDK has never mirrored is mirrored=False, md5_match=False.
        A type the SDK has, but at a different revision, is mirrored=True,
        md5_match=False — that is how a topic whose name is familiar but whose
        wire schema is not this one (``/robot_mode`` Bool vs Int8) shows up.

        The registry is produced by tools/limxsdk-gen (limxsdk.msg.registry),
        not a hand-written table.

        @param duration: Discovery wait in seconds, same as get_topics().
        @return: list[dict] with keys name, type, md5, mirrored, md5_match.
        """
        rows = self.robot.queryTopicSupport(duration)
        return [{"name": row[0], "type": row[1], "md5": row[2],
                 "mirrored": bool(row[3]), "md5_match": bool(row[4])}
                for row in rows]

    def getRobotDescription(self, port: int = 5000, timeout_ms: int = 3000):
        """
        @brief Fetches the robot's URDF description.

        The robot does not publish its URDF on any topic; it is a file served by
        the rbtmgr HTTP endpoint, which this helper reads over a plain socket.

        BLOCKING call, not a subscription: it performs a few short HTTP requests
        against the robot passed to init(), so call it during set-up rather than
        from a control loop.

        @param port: rbtmgr HTTP port on the robot.
        @param timeout_ms: Per-request send/receive timeout in milliseconds.
        @return: The URDF XML string, or None on failure.
        """
        return self.robot.getRobotDescription(port, timeout_ms)

    def publishBraincoHandCmd(self, cmd: datatypes.BraincoHandCmd):
        """
        @brief Publishes a brainco dexterous hand command to "/brainco2/hand/cmd".

        @param cmd: datatypes.BraincoHandCmd.
        @return: True on success, False otherwise.
        """
        return self.robot.publishBraincoHandCmd(cmd)

    def subscribeBraincoHandCmd(self, callback: Callable[[datatypes.BraincoHandCmd], Any]):
        """
        @brief Subscribes to "/brainco2/hand/cmd".

        @param callback: Callable[[datatypes.BraincoHandCmd], Any].
        @return: Subscription status.
        """
        return self.robot.subscribeBraincoHandCmd(callback)

    def subscribeBraincoHandState(self, callback: Callable[[datatypes.BraincoHandState], Any]):
        """
        @brief Subscribes to "/brainco2/hand/state".

        @param callback: Callable[[datatypes.BraincoHandState], Any].
        @return: Subscription status.
        """
        return self.robot.subscribeBraincoHandState(callback)
