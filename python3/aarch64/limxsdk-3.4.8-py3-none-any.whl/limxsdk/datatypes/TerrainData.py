﻿import sys

class TerrainData(object):
    __slots__ = ['stamp','height','width','step','data']
    def __init__(self):
        self.stamp = 0
        self.height = 0
        self.width  = 0
        self.step   = 1
        self.data = []
