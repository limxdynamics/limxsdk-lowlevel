﻿import sys
from typing import List
class ImuData(object):
    __slots__ = ['stamp','acc','gyro','quat']
    stamp: int
    acc: List[float]
    gyro: List[float]
    quat: List[float]
    def __init__(self):
        self.stamp = 0
        self.acc = [0. for x in range(0, 3)]
        self.gyro = [0. for x in range(0, 3)]
        self.quat = [0. for x in range(0, 4)]