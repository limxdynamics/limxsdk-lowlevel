"""
@brief Tron2 2F-gripper command data class.

Vectors are indexed per finger: [0]=left, [1]=right.
Values are normalized percentages in [0, 100]:
  - opening : commanded opening (0=closed, 100=open)
  - speed   : commanded motion speed
  - force   : commanded grasping force

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class GripperCmd(object):
    __slots__ = ['stamp', 'opening', 'speed', 'force']
    stamp: int
    opening: List[float]
    speed: List[float]
    force: List[float]

    def __init__(self):
        self.stamp = 0
        self.opening = [0.0, 0.0]
        self.speed = [0.0, 0.0]
        self.force = [0.0, 0.0]
