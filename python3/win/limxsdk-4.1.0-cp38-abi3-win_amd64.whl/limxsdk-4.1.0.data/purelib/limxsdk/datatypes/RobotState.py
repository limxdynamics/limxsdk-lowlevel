﻿import sys
from typing import List

class RobotState(object):
    __slots__ = ['stamp','tau','q','dq','motor_names']
    stamp: int
    tau: List[float]
    q: List[float]
    dq: List[float]
    motor_names: List[str]
    def __init__(self):
        self.stamp = 0
        self.tau = []
        self.q = []
        self.dq = []
        self.motor_names = []