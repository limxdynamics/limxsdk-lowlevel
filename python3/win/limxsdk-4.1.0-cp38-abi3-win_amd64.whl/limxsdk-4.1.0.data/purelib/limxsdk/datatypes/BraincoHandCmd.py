from typing import List

from .BraincoHandMsg import BraincoHandMsg


class BraincoHandCmd(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hand_cmd']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hand_cmd: List[BraincoHandMsg]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ""
        self.ctrl_mode = [0, 0]
        self.hand_cmd = [BraincoHandMsg(), BraincoHandMsg()]
