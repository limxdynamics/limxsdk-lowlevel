﻿import sys
from typing import List

class SensorJoy(object):
    __slots__ = ['stamp','axes','buttons']
    stamp: int
    axes: List[float]
    buttons: List[int]
    def __init__(self):
        self.stamp = 0
        self.axes = []
        self.buttons = []