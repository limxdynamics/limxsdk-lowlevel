from typing import List

from .BraincoHandMsg import BraincoHandMsg


class BraincoHandState(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hand_state']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hand_state: List[BraincoHandMsg]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ""
        self.ctrl_mode = [0, 0]
        self.hand_state = [BraincoHandMsg(), BraincoHandMsg()]
