"""
@brief One raw entry of the robot diagnostic stream, including the frame id.

Mirrors mros ``diagnostic_msgs/DiagnosticValue`` one-to-one and is delivered per
frame without coalescing. It exists alongside the older ``DiagnosticValue``
because that class cannot carry ``frame_id``, which several diagnostics (notably
"TeleOperation") use to distinguish sub-meanings of the same name.

Severity levels: ``0`` = OK, ``1`` = WARN, ``2`` = ERROR.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""


class DiagnosticEntry(object):
    OK = 0
    WARN = 1
    ERROR = 2

    __slots__ = ['stamp', 'name', 'frame_id', 'level', 'code', 'message']
    stamp: int
    name: str
    frame_id: str
    level: int
    code: int
    message: str

    def __init__(self):
        self.stamp = 0
        self.name = ''
        self.frame_id = ''
        self.level = 0
        self.code = 0
        self.message = ''
