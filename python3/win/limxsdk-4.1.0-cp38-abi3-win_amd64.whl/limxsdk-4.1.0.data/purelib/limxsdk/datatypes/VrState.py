"""
@brief VR head-set / hand-controller state data class.

Fed from the "/vr_cmd" topic, published by the VR bridge. This is a read-only
observation channel: it lets an application watch what the physical VR device
reports. Injecting synthetic VR input is a separate channel and is intentionally not
exposed here.

``eye_pose`` / ``left_pose`` / ``right_pose`` are row-major 4x4 homogeneous
transforms (16 floats each).

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class VrState(object):
    __slots__ = ['stamp', 'eye_pose', 'left_pose', 'right_pose',
                 'left_joystick', 'left_trigger', 'left_grip',
                 'left_thumb_touch', 'left_trigger_pressed', 'left_grip_pressed',
                 'button_x', 'button_y',
                 'right_joystick', 'right_trigger', 'right_grip',
                 'right_thumb_touch', 'right_trigger_pressed', 'right_grip_pressed',
                 'button_a', 'button_b']
    stamp: int
    eye_pose: List[float]
    left_pose: List[float]
    right_pose: List[float]
    left_joystick: List[float]
    left_trigger: float
    left_grip: float
    left_thumb_touch: bool
    left_trigger_pressed: bool
    left_grip_pressed: bool
    button_x: bool
    button_y: bool
    right_joystick: List[float]
    right_trigger: float
    right_grip: float
    right_thumb_touch: bool
    right_trigger_pressed: bool
    right_grip_pressed: bool
    button_a: bool
    button_b: bool

    def __init__(self):
        self.stamp = 0
        self.eye_pose = [0.0] * 16
        self.left_pose = [0.0] * 16
        self.right_pose = [0.0] * 16
        self.left_joystick = [0.0, 0.0]
        self.left_trigger = 0.0
        self.left_grip = 0.0
        self.left_thumb_touch = False
        self.left_trigger_pressed = False
        self.left_grip_pressed = False
        self.button_x = False
        self.button_y = False
        self.right_joystick = [0.0, 0.0]
        self.right_trigger = 0.0
        self.right_grip = 0.0
        self.right_thumb_touch = False
        self.right_trigger_pressed = False
        self.right_grip_pressed = False
        self.button_a = False
        self.button_b = False
