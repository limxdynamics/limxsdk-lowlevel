"""
@brief Measured end-effector pose of both arms.

Fed from the "/arm_pose" topic, whose payload is a flat array of 14 floats, 7 per arm,
ordered ``[x, y, z, qw, qx, qy, qz]``:

    data[0..2]    left  position
    data[3..6]    left  orientation quaternion (w, x, y, z)
    data[7..9]    right position
    data[10..13]  right orientation quaternion (w, x, y, z)

Notes:
  * The quaternion order is w-first, matching the manipulation controller's Cartesian
    servo protocol (xyz + qwxyz).
  * The wire message carries no header, so ``stamp`` is the SDK receive time.
  * ``valid`` is False when a frame did not carry the full 14-float layout; such
    frames are still delivered so a controller-side protocol change is visible
    instead of looking like "the arm stopped publishing".
  * The reference frame of these poses is defined by the manipulation controller and
    is not declared on the wire. Confirm the frame with the controller team before
    using the values for absolute positioning.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class ArmEePose(object):
    __slots__ = ['stamp', 'valid', 'left_position', 'left_quat',
                 'right_position', 'right_quat', 'data']
    stamp: int
    valid: bool
    left_position: List[float]
    left_quat: List[float]
    right_position: List[float]
    right_quat: List[float]
    data: List[float]

    def __init__(self):
        self.stamp = 0
        self.valid = False
        self.left_position = [0.0, 0.0, 0.0]
        self.left_quat = [0.0, 0.0, 0.0, 0.0]
        self.right_position = [0.0, 0.0, 0.0]
        self.right_quat = [0.0, 0.0, 0.0, 0.0]
        self.data = []
