"""
@brief Tron2 2F-gripper state feedback data class.

Vectors are indexed per finger: [0]=left, [1]=right.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class GripperState(object):
    __slots__ = ['stamp', 'q', 'v', 'vd', 'tau']
    stamp: int
    q: List[float]
    v: List[float]
    vd: List[float]
    tau: List[float]

    def __init__(self):
        self.stamp = 0
        self.q = []
        self.v = []
        self.vd = []
        self.tau = []
