﻿import sys
from typing import List

class TerrainData(object):
    __slots__ = ['stamp','height','width','step','data']
    stamp: int
    height: int
    width: int
    step: int
    data: List[float]
    def __init__(self):
        self.stamp = 0
        self.height = 0
        self.width  = 0
        self.step   = 1
        self.data = []
