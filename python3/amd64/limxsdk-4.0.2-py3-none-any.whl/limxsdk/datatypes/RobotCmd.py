﻿import sys
from typing import List

class RobotCmd(object):
    __slots__ = ['stamp','mode','q','dq','tau','Kp','Kd', 'motor_names', 'parallel_solve_required']
    stamp: int
    mode: List[int]
    q: List[float]
    dq: List[float]
    tau: List[float]
    Kp: List[float]
    Kd: List[float]
    motor_names: List[str]
    parallel_solve_required: List[bool]
    
    def __init__(self):
        self.stamp = 0
        self.mode = []
        self.q = []
        self.dq = []
        self.tau = []
        self.Kp = []
        self.Kd = []
        self.motor_names = []
        self.parallel_solve_required = []